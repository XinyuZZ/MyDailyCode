package s2122.hw1;

import java.text.DecimalFormat;
import java.util.HashSet;
import java.util.Set;

public class Main57017355 {

    public static void main(String[] args) {
        int escapeTimes = 1;
        int currentTrial = 0;
        int projectTrial = 1000000;

        for (int i = 1; i <= projectTrial; i++) {

            if (escapeSuccess) { //这里写错了
                escapeTimes++;
                currentTrial++;
            } else {
                currentTrial++;
            }
        }

        double escapeRate = (double) escapeTimes / (double) currentTrial;
        DecimalFormat format = new DecimalFormat("0.000");
        System.out.println("The Monte Carlo simulation result of one million runs:");
        System.out.println("No. of successful escape: " + escapeTimes);
        System.out.println("Success Rate P: " + format.format(escapeRate));
    }


    private boolean escapeSuccess(String path) {
        Set<Integer> vis = new HashSet<Integer>();
        int x = 0;
        int y = 0;
        vis.add(getHash(x, y)); //存入hash
        x++;

        vis.add(getHash(x, y)); //因为机器人是从（1，0）正式出发的
        int direction = (int) (Math.random() * 100); //生成随机移动方向
        if (direction >= 0 && direction <= 59) {//直行

            case (现在的y - 上个位置的y = -1):// 上一次的运动方向为朝上
                --y;
                if ((x >= 0 && x <= 6) && (y >= 0 && y <= 6)) //是否越界
                    vis.add(getHash(x, y)); //如果不越界 存入hash
                /**
                 * 继续前进 不知道咋写了。。
                 */
                if (!vis.add(getHash(x, y))){ //判断是否回到老位置
                    return true;//逃脱成功
                }
                else
                    return false; //逃脱失败




            case (现在的y - 上个位置的y = 1): //上一次的运动方向为朝下
                ++y;
                if ((x >= 0 && x <= 6) && (y >= 0 && y <= 6)) //是否越界
                    vis.add(getHash(x, y)); //如果不越界 存入hash
                else
                    return false; //逃脱失败
            case (现在的x - 上个位置的x = -1): //上一次的运动方向为朝左
                --x;
                if (x > 6 && y > 6)
                    vis.add(getHash(x, y));
                else
                    return false;
            case (现在的x - 上个位置的x = 1)://上一次的运动方向为朝右
                ++x;
                if (x > 6 && y > 6)
                    vis.add(getHash(x, y));
                else
                    return false;
        } else if (direction >= 60 && direction <= 79) { //左转
            case (现在的y - 上个位置的y = -1):// 上一次的运动方向为朝上
                --x;
                if (x > 6 && y > 6)
                    vis.add(getHash(x, y));
                else
                    return false;
            case (现在的y - 上个位置的y = 1): //上一次的运动方向为朝下
                ++x;
                if (x > 6 && y > 6)
                    vis.add(getHash(x, y));
                else
                    return false;
            case (现在的x - 上个位置的x = -1): //上一次的运动方向为朝左
                ++y;
                vis.add(getHash(x, y));
            case (现在的x - 上个位置的x = 1)://上一次的运动方向为朝右
                --y;
                if (x > 6 && y > 6)
                    vis.add(getHash(x, y));
                else
                    return false;

        } else if (direction >= 80 && direction <= 99) { //右转
            case (现在的y - 上个位置的y = -1):// 上一次的运动方向为朝上
                ++x;
                if (x > 6 && y > 6)
                    vis.add(getHash(x, y));
                else
                    return false;
            case (现在的y - 上个位置的y = 1): //上一次的运动方向为朝下
                --x;
                if (x > 6 && y > 6)
                    vis.add(getHash(x, y));
                else
                    return false;
            case (现在的x - 上个位置的x = -1): //上一次的运动方向为朝左
                --y;
                if (x > 6 && y > 6)
                    vis.add(getHash(x, y));
                else
                    return false;
            case (现在的x - 上个位置的x = 1)://上一次的运动方向为朝右
                ++y;
                if (x > 6 && y > 6)
                    vis.add(getHash(x, y));
                else
                    return false;

        }
        return false;
    }

    private int getHash(int x, int y) {
        return x * 20001 + y;
    }
}

/** 网上hash例子
//    class Solution {
//        public boolean isPathCrossing(String path) {
//            Set<Integer> vis = new HashSet<Integer>();
//
//            int x = 0, y = 0;
//            vis.add(getHash(x, y));
//
//            int length = path.length();
//            for (int i = 0; i < length; i++) {
//                char dir = path.charAt(i);
//                switch (dir) {
//                    case 'N':
//                        --x;
//                        break;
//                    case 'S':
//                        ++x;
//                        break;
//                    case 'W':
//                        --y;
//                        break;
//                    case 'E':
//                        ++y;
//                        break;
//                }
//                int hashValue = getHash(x, y);
//                if (!vis.add(hashValue)) {
//                    return true;
//                }
//            }
//
//            return false;
//        }

        public int getHash(int x, int y) {
            return x * 20001 + y; //计算hash值
        }
    }
**/


